<?php
require 'config.php';
require 'vendor/autoload.php';

    var_dump($_POST); die;
    $nome = $_POST['nome'];
    $fileName = $_FILES['file']['tmp_name'];

    if(file_exists($fileName)) {
        $arquivo = new \Johnnytec\Aula11\Emailsent;
    
        $resultado = $arquivo->send($fileName, $nome);
    }
    echo json_encode((['msg'=> $resultado ? "Enviado" : 'Nao enviado'  ]));

    // $fileName .= ".png";

    //abrir input no sweetalert e inserir um email
    
?>