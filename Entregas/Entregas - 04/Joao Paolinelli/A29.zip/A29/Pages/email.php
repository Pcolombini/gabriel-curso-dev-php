<html>
    <body>
        <form enctype="multipart/form-data" action="" method="POST">
            <label for="Nome">Nome:</label>
            <input type="text" name=nome> <br><br>

            <label for="">Arquivo</label>
            <input type="file" name="file">
            <button type='submit'>Enviar</button>
        </form>
    </body>
</html>