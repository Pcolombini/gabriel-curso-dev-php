<?php

    define("DB_HOST","localhost");
    define("DB_NAME","produto");
    define("DB_USER","root");
    define("DB_PWD","1");

   