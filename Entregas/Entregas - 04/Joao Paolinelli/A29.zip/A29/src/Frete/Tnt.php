<?php
namespace Johnnytec\Aula11\Frete;

class Tnt implements Frete{


    public function getPrice($valorProduto) {
        $calculo = $valorProduto * 0.0133;
        return $calculo > 0 ? round($calculo) : round($valorProduto/2);
    }

    public function getRaiz($raiz) {
        return 1;
    }

}