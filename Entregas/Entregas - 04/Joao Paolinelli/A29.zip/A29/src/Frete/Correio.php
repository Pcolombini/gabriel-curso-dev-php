<?php
namespace Johnnytec\Aula11\Frete;

class Correio implements Frete{

    public function getPrice($valorProduto) {
        $calculo = ($this->getRaiz(16) * (0.1 * $valorProduto))+ 1.7;
        return $calculo > 0 ? round($calculo) : round($valorProduto/2);
    }

    public function getRaiz($raiz) {
        return sqrt($raiz);
    }

}