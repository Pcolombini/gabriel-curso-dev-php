<?php
namespace Johnnytec\Aula11\Classes;

    class Produto extends Connect{


        public function getProduto($idProduto) {
          
            $con = $this->con;
            $rs = $con->prepare("SELECT * FROM produtos WHERE :idProduto = id_produto");
            $rs->bindParam('idProduto', $idProduto);
            return $rs->execute() ? $rs->fetchAll() : false;

        }

        public function printProduto() {
            echo '<hr>'. 'ID = ' .$this->atributos['id'].
            '<br> Nome = ' .$this->atributos['nome'].
            ' Valor = ' .$this->atributos['valor']. '<hr>';  
        }
    }