<?php
namespace Johnnytec\Aula11\Classes;

class Connect 
{
    //metodos magicos comecam com : __
    protected $con;

    public function __construct(){
        //pesquisando namespace(pacote) PDO
        $this->con = new \PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME,
            DB_USER,
            DB_PWD
        );
    }

    private function insert(\PDOStatement $sth) {
        if($this->executeQuery($sth)) {
            return $this->con->lastInsertId();
        }

    }

    private function executeQuery(\PDOStatement $sth) {
        return $sth->execute();
    }

    private function select(\PDOStatement $sth) {
        return $sth->execute() ? $sth->fetchAll(\PDO::FETCH_ASSOC) : false;
    }

   
    

    
}
