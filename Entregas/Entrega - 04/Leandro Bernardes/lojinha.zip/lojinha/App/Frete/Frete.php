<?php

namespace App\Frete;

interface Frete
{
    public function getValue($preco);
}


?>