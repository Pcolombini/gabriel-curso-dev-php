<?php
namespace Johnnytec\Aula11\Classes;
use Johnnytec\Aula11\Frete\Jadlog;
use Johnnytec\Aula11\Frete\Correio;
use Johnnytec\Aula11\Frete\Tnt;

class Compra extends Connect{
    private $produto;
    private $frete;
    private $recibo = array('p_valor'=> '','f_valor'=> '','t_valor'=> '');
    

    public function makeCompra() {
        $total = $this->getValor();

        $this->recibo['p_valor'] = $total;
        $this->recibo['f_valor'] = $this->frete->getPrice($total);
        $this->recibo['t_valor'] = round($total += $this->frete->getPrice($total));

        // echo '<br>'. 'Valor dos produtos = '. $total;
        // echo '<br>'. 'Valor do frete = '. $this->frete->getPrice($total);
        // echo '<br>'. 'TOTAL = '. round($total += $this->frete->getPrice($total)) ;
        return $this->recibo['t_valor'] > 0 ? true : false;
    }

    public function getValor() {
        
        return $this->produto[0]['valor_produto'];
    }

    public function addProduto($product) {
        
        $this->produto = $product;

    }
    public function getRecibo() {
        return  $this->recibo;
    }
    public function showCarrinho() {
        var_dump($this->produto);
    }
    public function printBoleto() {
        echo '<br>Produto = <span id="produto">'.$this->recibo['p_valor'].'</span>';
        echo '<br>Frete = <span id="frete">'.$this->recibo['f_valor'].'</span>';
        echo '<br>Total = <span id="total">'.$this->recibo['t_valor'].'</span>';
    }

    public function setFrete($idFrete) {
        $arrayFrete = array(
            '1' => new Tnt(),
            '2' => new Jadlog(),
            '3' => new Correio()
        );
        $this->frete = $arrayFrete[$idFrete];
        

    }
}