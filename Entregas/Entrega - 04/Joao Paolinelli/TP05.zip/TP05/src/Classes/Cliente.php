<?php
namespace Johnnytec\Aula11\Classes;

class Cliente {
    private $idCliente;
    private $nomeCliente;
    private $cpfCliente;
    
    public function __construct()
    {
        
    }
}