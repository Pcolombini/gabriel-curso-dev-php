<?php
namespace Johnnytec\Aula11\Frete;

 interface  Frete {
    
    public function getPrice($valorProduto);
    public function getRaiz($raiz);
}