<?php
namespace Johnnytec\Aula11\Frete;

class Jadlog implements Frete{
    private $id;
    

    public function getPrice($valorProduto) {
        $calculo= $valorProduto * 0.02;
        return $calculo > 0 ? round($calculo) : round($valorProduto/2);
    }

   
    public function getRaiz($raiz) {
        return sqrt($raiz);
    }

}