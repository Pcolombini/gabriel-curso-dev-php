<?php
use Johnnytec\Aula11\Emailsent;

require 'config.php';
require 'vendor/autoload.php';


$page =filter_input(INPUT_GET, 'page', FILTER_SANITIZE_STRING);
$filename = 'Pages/' . $page . '.php';
if(file_exists($filename)) {
    require $filename;
}
    // $objeto = new Emailsent();
    // $retorno = $objeto->send();
    // var_dump($retorno);
?>



<?php
    // var_dump($_POST);
    // var_dump($_FILES);
    // $nome = $_POST['nome'];
    // $fileName = $_FILES['file']['tmp_name'];
    // // $fileName .= ".png";
    // $arquivo = new Emailsent();
    
    // $arquivo->send($fileName, $nome);

    
?>