Associacao

Exemplo pacote =(controle remoto + televisao) classes indepentes


Relacioamento fraco

Agregacao

Composicao

Composer -> Gerenciador de pacotes(google play);
Dentro do gerenciador existem pacotes
Nos pacotes existem classes de 3.

composer init
composer dump-autoload


https://packagist.org/?query=phpmailer

add o phpmailer no require


composer install

//Nao possui um email autenticado
Message could not be sent. Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/TroubleshootingNULL



\PDO -> puxando do namespace global

coofecode.


