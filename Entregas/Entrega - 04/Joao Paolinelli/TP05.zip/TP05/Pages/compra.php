<!-- <?php

        ?> -->
<html>

<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.js"></script>
    <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" id="theme-styles">
</head>

<body>
    <form action="" method="POST" id='calculoFrete'>
        <label for="form">ID PRODUTO</label>
        <input type="text" name="id_produto">

        <label for="">ID FRETE</label>
        <input type="text" name="id_frete">

        <button type="submit" id='btEmail'>Enviar</button>

    </form>

    <table>
        <tr>
            <th>ID produto:</th>
            <th>ID FRETE:</th>

        </tr>
    </table>




    <?php
    if (!empty($_POST)) {

        echo '<br>' . ' Deseja receber o recibo via e-mail?' . ' <br>';
        echo '<button type="submit" id="receberEmail">Sim</button>';
    }

    ?>

    <!-- <script>
        $(document).ready(function() {
            $('#calculoFrete').click(function() {
                $('#enviarEmail').submit(function() {
                    $('#enviarEmail').show()
                })
            })
        })
    </script> -->

    <script>
        $(document).ready(function() {
            $('#btnEmail').click(function() {
                $('#enviarEmail').show()

            })
            $('#receberEmail').click(function() {
                // const {value: mail} = await
                Swal.fire({
                    title: 'Insira seu email:',
                    input: 'text',
                    inputAttributes: {
                        autocapitalize: 'off'
                    },
                    showDenyButton: true,
                    showCancelButton: false,
                    confirmButtonText: 'Enviar',
                    denyButtonText: `Cancelar`,
                }).then((result) => {
                    /* Read more about isConfirmed, isDenied below */

                    if (result.isConfirmed) {
                        // var myJ = $('#conteudo').html();
                        // var lock = document.getElementById('conteudo');

                        // var x = new FormData(lock);

                        // var x = myJ.outerHTML;
                        // var xxx = JSON.serialize();
                        // var jMy = new formData(myJ);

                        // var myForm = document.getElementById('calculoFrete');
                        // var formData = new FormData(myForm);
                        // alert($('#').text()),
                        // alert($('#produto').text()),
                        // alert($('#produto').text())

                        $.ajax({
                            url: '?page=resultado',
                           
                            type: 'POST',
                            dataType: 'json',
                            data: {
                                'produto': $('#produto').text(),
                                'frete': $('#frete').text(),
                                'total': $('#total').text(),
                                'email': result.value
                            },

                            beforeSend: function() {
                                //carregado
                            },

                        }).done(function(data) {
                            Swal.fire('Enviado com sucesso!', '', 'success')
                        });
                    } else if (result.isDenied) {
                        Swal.fire('Operacao cancelada', '', 'info')
                    }
                })
            })
        })
    </script>
</body>

</html>

<?php

use Johnnytec\Aula11\Classes\Produto;
use Johnnytec\Aula11\Classes\Compra;

use Johnnytec\Aula11\Emailsent;
use Johnnytec\Aula11\Frete\Jadlog;
use Johnnytec\Aula11\Frete\Correio;
use Johnnytec\Aula11\Frete\Tnt;

$idProduto = filter_input(INPUT_POST, 'id_produto', FILTER_SANITIZE_STRING);
$idFrete = filter_input(INPUT_POST, 'id_frete', FILTER_SANITIZE_STRING);
$idCliente = filter_input(INPUT_POST, 'id_cliente', FILTER_SANITIZE_STRING);

if ($idProduto && $idFrete) {
    echo '<hr>';
    echo 'Produto id: ' . ' ' . $idProduto . '<br>';
    echo 'Frete id: ' . ' ' . $idFrete;
    echo '<hr>';


    $objCompra = new Compra();
    $objProduto = new Produto();

    $t = $objCompra->addProduto($objProduto->getProduto($idProduto));
    // var_dump($objCompra->showCarrinho());
    $objCompra->setFrete($idFrete);

    // $produto = $objProduto->setProduto($idProduto);

    $statusCompra = $objCompra->makeCompra();
    $objCompra->printBoleto();
    $recibo = $objCompra->getRecibo();
    var_dump($recibo);
    $c1 = $recibo['p_valor'];
    $c2 = $recibo['f_valor'];
    $c3 = $recibo['t_valor'];

    // $c4 = $c1.' '.$c2.' '.$c3;




    // var_dump($recibo);
    // var_dump($total);
    // echo $produto[0]['valor_produto'];


    // $frete = $arrayFrete[$idFrete];
    // $calcularFrete = $frete->getPrice($produto[0]['valor_produto']);


    // $objCompra->showCarrinho();
}



// var_dump($_POST);
// $p = $produto->getProduto($idProduto);
// $f = $frete->getPrice($p['0']['valor_produto']);
// var_dump($p, $idProduto); die;
// var_dump($f);
// var_dump($f);
// $mail = new Emailsent();
$nomeUser = "Joao";
$freteNome = "TNT";
$nomeProduto = "Apple";

// $retorno = $mail->send($nomeUser,$freteNome,$nomeProduto);
// var_dump($retorno);


// if($idProdut0 != null && $idFrete != null) {
//     $produto = new Produto();

//     if($idFrete == 1) {
//         $frete 
//     }else if($idFrete == 2) {

//     }
// }




?>