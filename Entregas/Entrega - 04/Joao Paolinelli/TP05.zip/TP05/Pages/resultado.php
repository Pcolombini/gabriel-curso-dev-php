<?php
require 'config.php';
require 'vendor/autoload.php';
    // var_dump($_POST); die;
    $conteudo = $_POST['produto'].'  '.$_POST['frete'].'  '.$_POST['total'];
    $emailUser = $_POST['email'];
    // var_dump($conteudo, $emailUser); die;
    // var_dump($emailUser);
    

    $arquivo = new \Johnnytec\Aula11\Emailsent;
    
    $resultado = $arquivo->send($emailUser, $conteudo);
    var_dump($resultado); die;
    // if(file_exists($emailUser)) {
    //     $arquivo = new \Johnnytec\Aula11\Emailsent;
    
    //     $resultado = $arquivo->send($emailUser, $conteudo);
    // }
    echo json_encode((['msg'=> $resultado ? "Enviado" : 'Nao enviado'  ]));

    // $emailUser .= ".png";

    //abrir input no sweetalert e inserir um email
    
?>