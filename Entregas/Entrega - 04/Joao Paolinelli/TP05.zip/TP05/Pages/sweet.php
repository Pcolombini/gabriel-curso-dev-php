<?php

?>

<html>

<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.js"></script>
    <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" id="theme-styles">
</head>

<body>
    <form enctype="multipart/form-data" action="" method="POST" id='myFormulario'>
        <label for="Nome">Nome:</label>
        <input type="text" name=nome> <br><br>

        <label for="">Arquivo</label>
        <input type="file" name="file">
        <button type='button' id="btnEnviar">Enviar</button>
    </form>
</body>

<script>
    // Swal.fire('Eu estou funcionando?',
    //     'Alo Im here',
    //     'question'
    // )
    $(document).ready(function() {
        $('#btnEnviar').click(function() {
            Swal.fire({
                title: 'Excluir o usuario?',
                showDenyButton: true,
                showCancelButton: false,
                confirmButtonText: 'Save',
                denyButtonText: `Don't save`,
            }).then((result) => {
                /* Read more about isConfirmed, isDenied below */

                if (result.isConfirmed) {

                    var myForm = document.getElementById('myFormulario');
                    var formData = new FormData(myForm);

                    $.ajax({
                        url: 'resultado.php',
                        data: formData,
                        type: 'POST',
                        enctype: 'multipart/form-data',
                        processData: false,
                        contentType: false,
                        dataType: 'json',

                        beforeSend: function() {
                            //carregado
                        },

                    }).done(function(data) {
                        Swal.fire('Salvo com sucesso!', '', 'success')
                    });
                } else if (result.isDenied) {
                    Swal.fire('Nao salvo', '', 'info')
                }
            })
        })
    })
</script>

</html>