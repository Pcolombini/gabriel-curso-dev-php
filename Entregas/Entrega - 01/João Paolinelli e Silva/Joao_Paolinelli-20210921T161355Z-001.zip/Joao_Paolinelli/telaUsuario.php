<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
 $logado = false;

 class  Usuario {
    public $name;
    public $phone;
    public $mail;
    public $city;
    public $state;
    public $resume;
    public $languages;
    public $workIN;


    public function setValores($name,$phone,$mail,$city,$state,$resume,$language,$spanish,$work) : bool {

      if(!empty($name)) { $this->name = $name;
      }else { $this->name = 'nao informado';
      }

      if(!empty($phone)) { $this->phone = $phone;
      }else { $this->phone = 'nao informado';
      }

      if(!empty($mail)) { $this->mail = $mail;
      }else { $this->mail = 'nao informado';
      }
      
      if(!empty($city)) { $this->city = $city;
      }else { $this->city = 'nao informado';
      }
      
      if(!empty($state)) { $this->state = $state;
      }else { $this->state = 'nao informado';
      }
      
      if(!empty($resume)) { $this->resume = $resume;
      }else { $this->resume = 'nao informado';
      }
     
      if(!empty($language) && !empty($spanish)) { $this->languages = $language.' e '.$spanish;
      }else if(!empty($language)) { $this->languages = $language;
      }else if(!empty($spanish)){ $this->languages = $spanish;
      }else { $this->languages = 'nao informado';
      }
      
      if(!empty($work)) { $this->workIN = $work;
      }else { $this->workIN = 'nao informado';
      }

      return true;
    }

    public function makeXML() {
      $xml = new DOMDocument('1.0', 'ISO-8859-1');
        $xml->preserveWhiteSpace = false;
        $xml->formatOutput = true;

        $formulario = $xml->createElement('formulario_construSite');
        $user = $xml->createElement('user_dados');

        $n = $xml->createElement('nome', $this->name);
        $t = $xml->createElement('telefone', $this->phone);
        $m = $xml->createElement('email', $this->mail);
        $c = $xml->createElement('cidade', $this->city);
        $s = $xml->createElement('estado', $this->state);
        $r = $xml->createElement('resume', $this->resume);
        $ll = $xml->createElement('idiomas',$this->languages);
        $w = $xml->createElement('work_presencial', $this->workIN);


        $user->appendChild($n);
        $user->appendChild($t);
        $user->appendChild($m);
        $user->appendChild($c);
        $user->appendChild($s);
        $user->appendChild($r);
        $user->appendChild($ll);
        $user->appendChild($w);
        $formulario->appendChild($user);
        $xml->appendChild($formulario);
        $xml->save("formularios.xml");
        return $xml;
    }

    public function writeArquivo($nomeArquivo, $conteudo) : bool {
      
      if(file_exists($nomeArquivo)) {
        return true;
      }
      return false;
    }
    

    public function imprimir() {
      echo '<pre>';
      if(!empty($this->name)){ echo 'Usuario logado:'.$this->name.'<br>';
      }else { echo 'Usuario logado: ERRO'.'<br>';
      }

      if(!empty($this->phone)) { echo 'Telefone: '.$this->phone.'<br>';
      }else { echo 'Telefone: '.'ERRO'.'<br>';
      }

      if(!empty($this->mail)) {echo 'Mail: '.$this->mail.'<br>';
      }else {echo 'Mail: '.'ERRO'.'<br>';
      }
      
      if(!empty($this->city)) { echo 'Cidade: '.$this->city.'<br>';
      }else { echo 'Cidade: '.'ERRO'.'<br>';
      }

      if(!empty($this->state)) {echo 'Estado: '.$this->state.'<br>';
      }else {echo 'Estado: '.'ERRO'.'<br>';
      }

      if(!empty($this->resume)) {echo 'Resume: '.$this->resume.'<br>';
      }else {echo 'Resume: '.'ERRO'.'<br>';
      }

      if(!empty($this->languages) ) {print_r('Idioma: '.$this->languages.'<br>');
      }else {echo 'Idioma: '.'ERRO'.'<br>';
      }

      if(!empty($this->workIN)) {echo 'Trabalho presencial: '.$this->workIN.'<br>';
      }else {echo 'Trabalho presencial: '.'ERRO'.'<br>';
      }

    }
  
}
?>

  <?php

    $name = filter_input(INPUT_POST, 'customerName', FILTER_SANITIZE_STRING);
    $phone = filter_input(INPUT_POST, 'customerPhone', FILTER_SANITIZE_NUMBER_INT);
    $mail = filter_input(INPUT_POST, 'customerMail', FILTER_SANITIZE_EMAIL);
    $city = filter_input(INPUT_POST, 'customerCity',FILTER_SANITIZE_STRING);
    $state = filter_input(INPUT_POST, 'customerState');
    $resume = filter_input(INPUT_POST, 'customerResume',FILTER_SANITIZE_STRING);
    $language = filter_input(INPUT_POST, 'customerLanguage');
    $spanish = filter_input(INPUT_POST, 'customerLanguageS');
    $work = filter_input(INPUT_POST, 'customerWork');


    $usuario = new Usuario();
    $result = $usuario->setValores($name,$phone,$mail,$city,$state,$resume,$language,$spanish,$work);

    $objetoXML = $usuario->makeXML();

    print $objetoXML->saveXML();
        
    echo '<br>' . '-------------------<br>';
    echo '<br>' . '-------------------<br>';
    echo '<br>' . '-------------------<br>';

  ?>

</body>
</html>