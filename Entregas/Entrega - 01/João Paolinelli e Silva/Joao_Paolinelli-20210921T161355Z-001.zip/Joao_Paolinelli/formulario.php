
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script
    src="https://code.jquery.com/jquery-3.6.0.min.js"
    integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
    crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"> </script>
    <script type="text/javascript" src="js/script.js"></script>
    <script type="text/javascript" src="js/customMessage.js"></script>
    <link rel="stylesheet" href="style.css">

    
    <title>Document</title>
</head>
<body>
  <div id="site">
    <div id="header">
      <h3>Formulario</h3>
    </div>
  <div class="formularioCS col-12">
  <form action="telaUsuario.php" method="POST" id="myForm">
    <label for="customerName col-6" >Nome:</label>
    <input required type="text" id="customerName" name="customerName" value ="" >
    <br><br>

    <label for="customerPhone col-6">Telefone:</label>
    <input type="number" id="customerPhone" name="customerPhone" >
    <br><br>

    <label for="customerMail">E-mail:</label>
    <input type="email" id="customerMail" name="customerMail" required>
    <br><br>

    <label for="customerCity">Cidade:</label>
    <input type="text" id="customerCity" name="customerCity" required>
    <br><br>

    <label for="customerState">Estado:</label><br>
    <select name="customerState" id="customerState">
    <option value="">Selecione seu estado</option>
    <option value="MG" required>MG</option>
    <option value="SP" required>SP</option>
    <option value="RJ" required>RJ</option>
    <option value="ES" required>ES</option>
    </select>

    <br>
    <label for="customerResume">Resumo Profissional:</label><br>
    <textarea name="customerResume" id="customerResume"  rows="5" cols="40" required>
    </textarea>
    <br>
    <label for="customerLanguage">Idiomas:</label>
    <input type="checkbox" id="customerS" name="customerLanguage" value="Ingles" required> <label for="customerS">Ingles</label>
    <input type="checkbox" id="customerE" name="customerLanguageS" value="Espanhol" required> <label for="customerE">Espanhol</label>
    <br>

    <label for="customerWork">Trabalhar presencial:</label><br>
    Sim<input type="radio" id="customerWork" name="customerWork" value="SIM" required> 
    Nao<input type="radio" id="customerWork" name="customerWork" value="NAO" required><br>

      <br>
    <input  type="submit" >

  


  </form>
</div>
  </div>


<!-- <script>
  function isChecked() {
  var x = document.getElementById("customerE").required = true;
  var y = document.getElementById("customerS").required = true;
  var z = document.getElementById("customerWork").required;

  document.getElementById('demo').innerHTML = x ;
  document.getElementById('demo2').innerHTML = y ;
  document.getElementById('demo3').innerHTML = z ;
  

  
}
</script>
<button onclick="isChecked()" id="send">try it</button>
  <p id ="demo"></p>
  <p id ="demo2"></p>
  <p id ="demo3"></p> -->

</body>
</html>