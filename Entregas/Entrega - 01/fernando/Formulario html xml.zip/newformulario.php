<!DOCTYPE html>
<html>

<head>

    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@1,300&display=swap" rel="stylesheet">

    <title> Formulário</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.3/jquery.validate.min.js"></script>
    <script src="js/scripts.js"></script>

    <style>
        body {
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
            font-size: medium;
            color: bisque
        }
    </style>

</head>




<body BACKGROUND="https://i1.wp.com/emotioncard.com.br/wp-content/uploads/2019/04/plano-de-fundo-preto28.jpg?resize=1024%2C640&ssl=1">


    <h1 id="cabecalhoh1">COMPLETE OS DADOS ABAIXO:</h1>

    <form method="POST" action="" id="myCustonForm"  onsubmit="Customerareaprofissional()">
        <input name="customername" type="text" placeholder="Nome">
        <br>
        <br>
        <input name="customeremail" type="text" placeholder="Email">
        <br>
        <br>
        <input name="customeridade" type="text" placeholder="Idade">
        <br>
        <br>
        <input name="customertel" type="text" placeholder="Telefone">
        <br>
        <br>

            <label for="">DISPONÍVEL PARA TRABALHO PRESENCIAL?:</label>
            <INPUT TYPE="radio" NAME="OPCAO" VALUE="op1"> SIM
            <INPUT TYPE="radio" NAME="OPCAO" VALUE="op2"> NÃO


        <br>
        <br>



        <select required>
            <option value="" disabled selected>Idiomas...</option>



            



            <option value="Ingles">Ingles</option>
            <option value="Espanhol">Espanhol</option>
            <option value="Frances">Frances</option>
            <option value="Nenhum acima">Nenhum acima</option>

        </select>



        <select required>
            <option value="" disabled selected>Estado...</option>







            <option value="MG">MG</option>
            <option value="SP">SP</option>
            <option value="RJ">RJ</option>
            <option value="ES">ES</option>

        </select>
        <br>
        <br>
        <label for="">RESUMO PROFISSIONAL:</label>
        <br>
        <textarea name="customerprofissional" placeholder="Profissional"> </textarea>


        <button type="submit">Enviar</button>

        <script>
            function Customerareaprofissional() {
                alert('Formulário Enviado')
            }
        </script>


    </form>





    <h1>
        <p></p>


    </h1>
</body>

<footer></footer>



</html>


<?php

echo $_POST["customername"];
echo "<br>";
echo $_POST["customeremail"];
echo "<br>";
echo $_POST["customertel"];
echo "<br>";
echo $_POST["customerprofissional"];
echo "<br>";


$Nome = filter_input(INPUT_POST, "customername");
$Email = filter_input(INPUT_POST, "customeremail");
$Telefone = filter_input(INPUT_POST, "customertel");
$Idade = filter_input(INPUT_POST, "customeridade");
$Profissional = filter_input(INPUT_POST, "customerprofissional");
$ingles = filter_input(INPUT_POST, "Ingles");
$espanhol = filter_input(INPUT_POST, "Espanhol");
if (!$Nome) {
    echo "preencha o campo nome";
} elseif (!$Email) {
    echo "preencha o campo email" . "  .  " . "prencha o campo telefone";
} elseif (!$Telefone) {
    echo "preencha o campo telefone";
} elseif (!$Idade) {
    echo "Digite sua idade";
} elseif (!$Profissional) {
    echo "Campo Obrigatorio";
}else {
    echo "Sucess";
}


//Arquivo xml
$xml = '?xml version = "1.0" encoding = "UTF-8"?';
$xml .= '<links>';

//criando links
$meus_links = array();

$meus_links[0]['Nome'] =  "Seu nome: " . $Nome . ".";
$meus_links[0]['Telefone'] = "Seu número de telefone: " . $Telefone . ".";
$meus_links[0]['Email'] = "Seu email " . $Email . ".";
//$meus_links[0]['Estado'] = "Seu estado " . $Estado . ".";
//$meus_links[0]['Profissional'] = "Seu resumo profissional " . $rpro . ".";
//$meus_links[0]['sim'] = $sim;
//$meus_links[0]['nao'] = $nao;

    if ($ingles && $espanhol){
        $xml .= '<idioma>Idiomas falados: Inglês e espanhol.</idioma>';
    }else if($ingles){
        $xml .= '<idioma>Idioma falado: Inglês.</idioma>';
    //}else if($espanhol){
        $xml .= '<idioma>Idioma falado: Espanhol.</idioma>';
    }else{
        $xml .= '<idioma>Nenhum outro idioma falado.</idioma>';
    }

    //if($sim){
      //  $xml .= '<disponibilidade>Disponibilidade para trabalhar presencialmente.</disponibilidade>';
    //}else {
       // $xml .= '<disponibilidade>Sem disponibilidade para trabalhar presencialmente.</disponibilidade>';
   // }


$xml .= '</links>';

//escrever no arquivo
$fp = fopen ('meus_links.xml','w+');
fwrite($fp, $xml);
fclose($fp);


?>