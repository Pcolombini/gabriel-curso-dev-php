$(function(){
    $('#myCustonForm').validate({
        rules:{
            customername: {
                required: true,
                minlength:5,
            },
            customeremail: {
                required: true,
                email: true,

                

            },
            customertel: {
                required: true,
                
            }

            }
        }
    )
})