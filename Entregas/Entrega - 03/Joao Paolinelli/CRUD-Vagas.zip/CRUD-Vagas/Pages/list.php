
<html>
  <head>
    <style>
      table{font-family: arial, sans-serif; border-collapse: collapse; width: 100%;}
      td,th {border: 1px solid #dddddd;text-align: left;padding: 8px;}
      tr:nth-child(even){background-color: #dddddd;}
    </style>

   
    <title>Candidatos</title>
  </head>
  <body>

    <h2>CRUD Candidatos</h2>
    <a href="?page=form&id_cliente= ">Cadastrar    |</a>
    <a href="?page=desativado&exc_clliente= F">Candidatos desativados</a>

    <hr>
    <table> 
        <tr>
          <th>Nome</th>
          <th>Telefone</th>
          <th>Email</th>
          <th>Estado</th>
          <th>Cidade</th>
          <th>Idioma</th>
          <th>Local</th>

          <th>Opcoes</th>
        </tr>
    
  </body>
  <script>
    $(document).ready(function(){
        $('#deleteUser').on('click',function(e){
            e.preventDefault();
            Valor = <? $_GET['id_delete'] ?>;
            Parametro_GET = <? $_GET['id_delete'] ?>;
            var valor = document.getElementsByClassName('linha'+Parametro_GET);
            var xml = new XMLHttpRequest();
            xml.open('GET', "?page=list");
            xml.responseType = 'document';
            xml.send();
            $('.linha'+ valor).hide();
        })
       
    })

    function desaparecer($chave) {
        
        $.ajax({
            type: 'POST',
            dataType: 'html',
            url:'?page=busca',
            beforeSend: function() {
                $('$dados').html("Carregando...");
            },
            data: {palavra: palavra},
            done: function(msg) {
                $('#dados').html(msg);
            }
        });
    }

    $('#buscar').click(function(){
        desaparecer($('#palavra').val())
    });

</script>
</html>
<?php
    $objeto = new Connect();
    $candidatos = $objeto->getCandidatos_ativo();
    
      
      foreach ($candidatos as $chave =>$candidato) {
          
        echo '<div class="linha'.$chave.'"
          <tr id="chave'.$candidato['id'].'">   
          <th ">'.$candidato['nome_candidato'].'</th>
          <th>'.$candidato['telefone_candidato'].'</th>
          <th>'.$candidato['email_candidato'].'</th>
          <th>'.$candidato['estado_candidato'].'</th>
          <th>'.$candidato['cidade_candidato'].'</th>
          <th>'.$candidato['idioma_candidato'].'</th>
          <th>'.$candidato['local_candidato'].'</th>

          <th><a href="?page=form&id= '.$candidato['id'].'">Editar</button>
          <a id="deleteUser"style="margin-left:10px" href="?page=list&id_delete= '.$candidato['id'].'" value="'.$candidato['id'].'"> Apagar</button>
          </th>
         
          </tr></div>';
        
        
      };
    echo '</table>';

?>
<?php

    $idDeletar = filter_input(INPUT_GET,'id_delete',FILTER_SANITIZE_STRING);
    $idAtivar = filter_input(INPUT_GET,'id_ativar',FILTER_SANITIZE_STRING);


    if($idDeletar) {
        $objeto->setCandidato_off($idDeletar);
        header("Refresh");

    }else if($idAtivar) {
        $objeto->setCandidato_on($idAtivar);
        header("Refresh");

    }

?>