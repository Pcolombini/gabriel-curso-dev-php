<?php

    $objeto = new Connect();
    $candidatos = $objeto->getCandidatos_off();

?>

<html>
    <head>
      <style>
        table{font-family: arial, sans-serif; border-collapse: collapse; width: 100%;}
        td,th {border: 1px solid #dddddd;text-align: left;padding: 8px;}
        tr:nth-child(even){background-color: #dddddd;}
      </style>

    <title>Candidatos desativados</title>
    </head>

    <body>
    <h3>Candidados off</h3>
    <a href="?page=form&id_cliente= ">Cadastrar    |</a>
    <a href="?page=list&#">Voltar</a>
    <hr>
    <table> 
        <tr>
          <th>Nome</th>
          <th>Telefone</th>
          <th>Email</th>
          <th>Estado</th>
          <th>Cidade</th>
          <th>Idioma</th>
          <th>Local</th>

          <th>Opcoes</th>
        </tr>

    </body>

  
</html>

<?php
    foreach ($candidatos as $chave =>$candidato) {
            
        echo '<div class="linha'.$candidato['id'].'"
          <tr class="'.$candidato['id'].'">   
          <th ">'.$candidato['nome_candidato'].'</th>
          <th>'.$candidato['telefone_candidato'].'</th>
          <th>'.$candidato['email_candidato'].'</th>
          <th>'.$candidato['estado_candidato'].'</th>
          <th>'.$candidato['cidade_candidato'].'</th>
          <th>'.$candidato['idioma_candidato'].'</th>
          <th>'.$candidato['local_candidato'].'</th>

          <th><a href="?page=form&id= '.$candidato['id'].'">Editar</button>
          <a id="ativarUser"style="margin-left:10px" href="?page=list&id_ativar= '.$candidato['id'].'" value="'.$candidato['id'].'"> Ativar</button>
          </th>
          </tr></div>';
        
        
      };
    echo '</table>';
?>