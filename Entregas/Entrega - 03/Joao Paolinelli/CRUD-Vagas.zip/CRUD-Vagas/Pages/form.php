<?php
    $idCandidato = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_STRING);
    $objeto = new Connect();

    if($idCandidato) {
        
        $interface = 'U'; // U = UPDATE
        $candidato = $objeto->getCandidato_byID($idCandidato);
        // var_dump($candidato); die;
        $candidato = $candidato[0];
    }else {
        $interface = 'I'; // I = INSERT
    }

?>

<html>
<head> 
<script
            src="https://code.jquery.com/jquery-3.2.1.min.js"
            integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4="
        crossorigin="anonymous">
</script>
<title>Formulario</title></head>

<body>

<h3>Johnny Company</h3>

<form method="POST" action="" class='inserirAjax listarAjax' id='userAjax'>
    <fieldset>
        <legend>Formulario de vagas</legend>

        <label for="nCandidato">Nome: </label>
        <input type="text" id="nCandidato" name="nCandidato" value="<?= !empty($idCandidato) ? $candidato['nome_candidato'] : "" ?>"> <br><br>

        <label for="pCandidato">Telefone: </label>
        <input type="text" id="pCandidato" name="pCandidato" value="<?= !empty($idCandidato) ? $candidato['telefone_candidato'] : "" ?>"> <br><br>

        <label for="mCandidato">E-mail: </label>
        <input type="text" id="mCandidato" name="mCandidato" value="<?= !empty($idCandidato) ? $candidato['email_candidato'] : "" ?>"> <br><br>

        <label for="eCandidato">Estado: </label>
        <select name="eCandidato" id="eCandidato">
            <option ><?= !empty($idCandidato) && $candidato['estado_candidato'] != null ? $candidato['estado_candidato'] : "Selecione um estado" ?></option>
            <option name='eCandidato'value="MG">MG</option>
            <option name='eCandidato'value="SP">SP</option>
            <option name='eCandidato'value="ES">ES</option>
            <option name='eCandidadto'value="RJ">RJ</option>
        </select> <br><br>

        <label for="cCandidato">Cidade:</label>
        <input type="text" id="cCandidato" name="cCandidato" value="<?= !empty($idCandidato) ? $candidato['cidade_candidato'] : "" ?>">> <br><br>

        <label for="rCandidato">Resumo: </label>
        <br>
        <textarea type="textarea" id="rCandidato" name="rCandidato" rows="4" cols="12" value="<?= !empty($idCandidato) ? $candidato['resumo_candidato'] : "" ?>"><?= !empty($idCandidato) ? $candidato['resumo_candidato'] : "" ?></textarea> <br><br>

        <label for="iCandidato">Idioma: </label> <br>
        

        <input type="checkbox" id="iCandidato" name='iCandidato' value="Ingles"> Ingles
        <input type="checkbox" id="iCandidato" name='iCandidato' value="Espanhol"> Espanhol <br><br>

        <label for="wCandidato"> Local:</label> <br>
        <input type="radio" id="wCandidato" name='lCandidato' value="Presencial"> Presencial
        <input type="radio" id="wCandidato" name='lCandidato' value="Remoto"> Remoto <br><br>
        <input type="hidden" value="<?= $interface ?>" id="comando" name="interfaceAcao">

        <a href="?page=link"> <button  id=''type="submit" value='<?=!empty($idCandidato)? "Atualizar" : "Cadastrar"?>'> <?= !empty($idCandidato)? "Atualizar" : "Cadastrar" ?> </button> </a>
        <br>
        <!-- <a href='?page=salvar' id='btnSalvar' value="forChange">BIP BIP</a>

        <div id='resultado'>ID</div> -->

    </fieldset>


</form>

 

</body>

<script>
    $(document).ready(function(){

        $('#btnSalvar').click(function() {
           var dados = $('#userAjax').serialize();

            // $.post("?page=salvar", {
            //     dados
            // }, function(dados) {
            //     $('#resultado').html(dados);
            // });
            
            $.ajax( {
                type: 'POST',
                dataType: 'json',
                url: 'salvar.php',
                async: true,
                data: dados,
                success: function(response) {
                    window.location.assign('salvar.php');
                }
            }).done(function(data){
                window.location.assign('salvar.php');

                console.log(data);
            });

            return false;


            console.log(dados);
            
        });
        // console.log("Im here");
    });
   

</script>

</html>

   
<?php

    $a = array(
        'nCandidato' => filter_input(INPUT_POST, 'nCandidato', FILTER_SANITIZE_STRING),
        'pCandidato' => filter_input(INPUT_POST, 'pCandidato', FILTER_SANITIZE_STRING),
        'mCandidato' => filter_input(INPUT_POST, 'mCandidato', FILTER_SANITIZE_STRING),
        'eCandidato' => filter_input(INPUT_POST, 'eCandidato', FILTER_SANITIZE_STRING),
        'cCandidato' => filter_input(INPUT_POST, 'cCandidato', FILTER_SANITIZE_STRING),
        'rCandidato' => filter_input(INPUT_POST, 'rCandidato', FILTER_SANITIZE_STRING),
        'iCandidato' => filter_input(INPUT_POST, 'iCandidato', FILTER_SANITIZE_STRING),
        'lCandidato' => filter_input(INPUT_POST, 'lCandidato', FILTER_SANITIZE_STRING)

    );

    $interface = filter_input(INPUT_POST, 'interfaceAcao', FILTER_SANITIZE_STRING);

    if($_POST) {
        if($interface == 'U') {
            $a['id'] = $idCandidato;
            $candidato = $objeto->setCandidato_update($a);
            // echo '<hr>';
            // var_dump($_POST); die;
        }else if($interface == 'I') {
            $candidato = $objeto->criarCandidato($a);
        }

        if($candidato) {
            header('Location: ?page=list');
        }else { header('Location: ?page=list');}
    }

?>