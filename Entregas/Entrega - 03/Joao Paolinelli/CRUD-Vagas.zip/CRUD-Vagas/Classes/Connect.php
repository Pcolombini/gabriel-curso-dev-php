<?php

class Connect 
{
    private $con;

    public function __construct(){
        //pesquisando namespace(pacote) PDO
        $this->con = new \PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME,
            DB_USER,
            DB_PWD
        );
    }
    public function query($sql) {
        $con = $this->con;
        $rs = $con->prepare($sql);
        return $rs->execute() ? $rs->fetchAll(PDO::FETCH_ASSOC) : false;
    }
    
    //CREATE
    public function criarCandidato($arrayCandidato) {
        $con = $this->con;
        $rs = $con->prepare(
        "INSERT INTO candidatos(nome_candidato,telefone_candidato, email_candidato,estado_candidato, cidade_candidato, resumo_candidato, idioma_candidato,
         local_candidato, exc_candidato)
        VALUES(:nCandidato,:pCandidato,:mCandidato,:eCandidato,:cCandidato,:rCandidato,:iCandidato,:lCandidato, 'On');");
        $rs->bindParam('nCandidato', $arrayCandidato['nCandidato']);
        $rs->bindParam('pCandidato',$arrayCandidato['pCandidato']);
        $rs->bindParam('mCandidato',$arrayCandidato['mCandidato']);
        $rs->bindParam('eCandidato', $arrayCandidato['eCandidato']);
        $rs->bindParam('cCandidato', $arrayCandidato['cCandidato']);
        $rs->bindParam('rCandidato', $arrayCandidato['rCandidato']);
        $rs->bindParam('iCandidato', $arrayCandidato['iCandidato']);
        $rs->bindParam('lCandidato', $arrayCandidato['lCandidato']);

        return $rs->execute() ? $rs->fetchAll(PDO::FETCH_ASSOC) : false;

    }

    //READ
    public function getCandidato_byID($idCandidato) {
        $con = $this->con;
        $rs = $con->prepare(
        "SELECT *
        FROM candidatos
        WHERE candidatos.id = :idCandidato");

        $rs->bindParam('idCandidato',$idCandidato);

        return $rs->execute() ? $rs->fetchAll(PDO::FETCH_ASSOC) : false;
    }

    public function getCandidatos_ativo() {
        $con = $this->con;

        $rs = $con->prepare(
        "SELECT id, nome_candidato, telefone_candidato, email_candidato, estado_candidato, cidade_candidato, idioma_candidato, local_candidato
        FROM candidatos
        WHERE candidatos.exc_candidato = 'On' ");

        return $rs->execute() ? $rs->fetchAll(PDO::FETCH_ASSOC) : false;

    }

    public function getCandidatos_off() {
        $con = $this->con;

        $rs = $con->prepare(
        "SELECT id, nome_candidato, telefone_candidato, email_candidato, estado_candidato, cidade_candidato, idioma_candidato, local_candidato
        FROM candidatos
        WHERE candidatos.exc_candidato = 'Off' ");

        return $rs->execute() ? $rs->fetchAll(PDO::FETCH_ASSOC) : false;

    }
    

    //UPDATE
    public function setCandidato_update($arrayCandidato) {
        $con = $this->con;
        
        $rs = $con->prepare(
        "UPDATE candidatos 
        SET nome_candidato = :nCandidato, telefone_candidato = :pCandidato, email_candidato = :mCandidato
        , estado_candidato = :eCandidato, cidade_candidato = :cCandidato, idioma_candidato = :iCandidato, local_candidato = :lCandidato
        WHERE id = :idCandidato");
        
        $rs->bindParam('nCandidato', $arrayCandidato['nCandidato']);
        $rs->bindParam('pCandidato',$arrayCandidato['pCandidato']);
        $rs->bindParam('mCandidato',$arrayCandidato['mCandidato']);
        $rs->bindParam('eCandidato', $arrayCandidato['eCandidato']);
        $rs->bindParam('cCandidato', $arrayCandidato['cCandidato']);
        $rs->bindParam('iCandidato', $arrayCandidato['iCandidato']);
        $rs->bindParam('lCandidato', $arrayCandidato['lCandidato']);
        $rs->bindParam(':idCandidato', $arrayCandidato['id']);

        
        return $rs->execute() ? $rs->fetchAll(PDO::FETCH_ASSOC) : false;
    }

    public function setCandidato_on($idCandidato) {
        $con = $this->con;
        // var_dump($arrayCandidato); die;
        $rs = $con->prepare(
        "UPDATE candidatos 
        SET exc_candidato = 'On'
        WHERE id = :idCandidato");
        
        $rs->bindParam(':idCandidato', $idCandidato);

        
        return $rs->execute() ? $rs->fetchAll(PDO::FETCH_ASSOC) : false;
    }
    

    //DELETE
    public function setCandidato_off($idCandidato) {
        $con = $this->con;

        $rs = $con->prepare(
        "UPDATE candidatos
        SET exc_candidato = 'Off'
        WHERE id = :idCandidato");

        $rs->bindParam('idCandidato', $idCandidato);
        return $rs->execute() ? $rs->fetchAll(PDO::FETCH_ASSOC) : false;
    }


    //xml

    

    



    
}