$(document).ready(function(){
    /*
    $("#userEstado").click(function(){
        var estado = $("#userEstado").val();

        if(estado != ""){
            $(".form-hide").show();
        }else{
            $(".form-hide").hide();
        }
        //window.location.href = "?page=cidades&ufEstado=MG";
    });

    
    function addParameterToURL(param,count){
        var _url = location.href;
        if(count <= 1){
            _url += (_url.split('?')[1] ? '&estado=':'?') + param;
        }
        return _url;
    }

    function armazena(){
        localStorage.setItem('userName',$("#userName").val());
        localStorage.setItem('userPhone',$("#userPhone").val());
        localStorage.setItem('userEmail',$("#userEmail").val());
        localStorage.setItem('userEstado',$("#userEstado").val());
        localStorage.setItem('userResumo',$("#userResumo").val());

        if($("#userIngles").is(":checked")){
            localStorage.setItem('userIngles','true');
        }else{
            localStorage.setItem('userIngles','false');
        }

        if($("#userEspanhol").is(":checked")){
            localStorage.setItem('userEspanhol','true');
        }else{
            localStorage.setItem('userEspanhol','false');
        }

        if($("#userSim").is(":checked")){
            localStorage.setItem('userSim','true');
        }else{
            localStorage.setItem('userSim','false');
        }
        
        if($("#userNao").is(":checked")){
            localStorage.setItem('userNao','true');
        }else{
            localStorage.setItem('userNao','false');
        }
    }
    */
});